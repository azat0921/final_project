const express = require('express');
const app = express();
const path = require('path');




// This command is used to serve the CSS files 
// which are kept in the CSS folder from the working directory.
app.use(express.static(path.join(__dirname,'public')));
app.use(express.static(path.join(__dirname,'image')));


app.set('port' , 3000 || process.env.PORT)


app.get('/',(req, res) => {
   res.status(200);
    res.sendFile( __dirname + "/public/index.html" );
 })

 app.get('/index.html',(req, res) => {
   res.status(200);
    res.sendFile( __dirname + "/public/index.html" );
 })

app.get('/about', (req, res) => {
   res.status(200);
   res.sendFile( __dirname + "/public/about.html" );
})

app.get('/style.css', (req, res) => {
   res.status(200);
   res.sendFile( __dirname + "/style.css" );
})

app.get('/about/team_photo', (req, res) => {
    res.status(200);
    res.sendFile( __dirname + "/public/image/team.jpg" );
})
 
// Redirects to the URL derived from the specified path, with specified status, 
// a positive integer that corresponds to an HTTP status code .
// If not specified, status defaults to “302 “Found”.
app.get('/video', (req, res) => {
   res.redirect('https://www.youtube.com/watch?v=yXS8iNKqsCM&ab_channel=RLFComps')
})


// https://images.hive.blog/0x0/http://i239.bxjyb2jvda.net/img/mask.gif

app.use(function (req, res, next) {
   res.status(404).redirect('https://images.hive.blog/0x0/http://i239.bxjyb2jvda.net/img/mask.gif')
 })




app.use((err,req,res, next) => {
   console.error(err.stack);
   res.type("text/plain");
   res.status(500);
   res.send("500 - Iternal Error");
})

app.listen(app.get('port'), () => {
   console.log(`Express server on localhost${app.get('port')}; Press CTR+C to terminate`);
})

