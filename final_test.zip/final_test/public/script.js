
// Arrays to store list of players


var player1 = [];
var player2 = [];





// function refresh the page
function fun() {  
	location.reload();  
}  

// number of lines
function countLines() {
		
	// Count each line by '\n'
	var count = document.getElementById("floatingTextarea1").value.split("\n").length;  
	var count2 = document.getElementById("floatingTextarea2").value.split("\n").length;

	console.log(count2);


	// convert our goals to numbers
	let team1 = Number(number1.value); 
	let team2 = Number(number2.value);

	
	
	// by the rules of football there shouldn't be more than 11 or less than 7 people in each team

	 if(count > 11 || count < 7){
		alert("The numbers of players in team1 must be no more than 11 or less than 7!");
		errors();
		return true;

	}
	else if(count2 > 11 || count2 < 7){
		alert("The numbers of players in team2 must be no more than 11 or less than 7!");
		errors();
		return true;
	}
	 

	// if we fill the areas we can start to determine the winner
	if(count || count2 || team1 >= 0 || team2 >= 0 ){

		if(team1+team2 > 7){
			alert("The combined number of goals cannot be greater than 7!");
			errors();

		}
		// since we have "input type = number" we can scroll the number to negative sign
		// we chack ,is our goal vlaue negative or positive
		else if(team1 < 0 || team2 < 0){
			alert("The number of goal can't be negative!");
			errors();
		}
		//  in case both the teams get '0's 
		else if(team1=='0' && team2=='0'){
			document.getElementById("demo").innerHTML = ' ';
			score(team1);
			score(team2);
			
			 calculate();

		}

		else{
			if(team1 > team2){
				document.getElementById("demo").innerHTML = 'The winner is team1';
			}
			else if(team1 < team2){
				document.getElementById("demo").innerHTML = 'The winner is team2';
			}
			
			else{
				document.getElementById("demo").innerHTML = 'Draw!';
			}
			
			score(team1);
			score(team2);
			
			 calculate();

			
		}
		
	}
	
			
	
	
}


// Here set of answers to user as template
function errors(){
		document.getElementById("demo").innerHTML = 'Output will be here';
		document.getElementById("demo2").innerHTML = '';
		document.getElementById("demo3").innerHTML = '';
}


// here we record our players to array

const calculate = () => {
	player1 = document.getElementById("floatingTextarea1").value.split('\n');
    player2 = document.getElementById("floatingTextarea2").value.split('\n');
	console.log('Team1 List :');
	getElementArr(player1);

	console.log('Team2 List :');
	getElementArr(player2);
}

// we use forEach to display them to console
	
const getElementArr = (p1) => {  
    p1.forEach(item => {

        console.log(item);
    })
    
}






// score() - show the score list of the teams
// here we several probabilties how game can be finished

function score(scoreList){
	
	
	let num;
	let num2

	// we prepare for each case
		switch(scoreList){
			case 0:
				if(document.getElementById("number1").value==0){
					document.getElementById("demo2").innerHTML = '0';
				}
				if(document.getElementById("number2").value==0){
					document.getElementById("demo3").innerHTML = '0';
				}
				
				
			break;
			case 1:
				if(document.getElementById("number1").value==1){
					document.getElementById("demo2").innerHTML = '1';
				}
				if(document.getElementById("number2").value==1){
					document.getElementById("demo3").innerHTML = '1';
				}
				
				
			break;

			case 2:
				// to show to user different ending of the game we use Math.random()
				var arr2 = ["1 1" , "2"];
				num = Math.floor(Math.random() * 2);
				num2 = Math.floor(Math.random() * 2);

				
				
						if(document.getElementById("number1").value==2){
							document.getElementById("demo2").innerHTML = arr2[num];
						}
						if(document.getElementById("number2").value==2){
							document.getElementById("demo3").innerHTML = arr2[num2];
						}
						
				
			break;

			case 3:

				var arr3 = ["1 1 1", "1 2" , "2 1" , "3"];
				
				num = Math.floor(Math.random() * arr3.length);
				num2 = Math.floor(Math.random() * arr3.length);

			
					if(document.getElementById("number1").value==3){
					document.getElementById("demo2").innerHTML = arr3[num];
					}

					if(document.getElementById("number2").value==3){
					document.getElementById("demo3").innerHTML = arr3[num2];
					}
				

			break;


			case 4:
				
				var arr4 = ["1 1 1 1", "1 3" , "3 1", "1 1 2" , "1 2 1", "2 1 1" , "2 2","4"];
				
				
				num = Math.floor(Math.random() * arr4.length);
				num2 = Math.floor(Math.random() * arr4.length);
				if(document.getElementById("number1").value==4){
					document.getElementById("demo2").innerHTML = arr4[num];
				}
				if(document.getElementById("number2").value==4){
					document.getElementById("demo3").innerHTML = arr4[num2];
				}
				

			

			break;

			case 5:
				
				var arr5 = ["1 1 1 1 1", "1 1 3" , "1 3 1" , "3 1 1" , "1 1 1 2",
				 "1 1 2 1", "1 2 1 1", "2 1 1 1",  "4 1", "1 4", "3 2" , "2 3", "5"];
				
				num = Math.floor(Math.random() * arr5.length);
				num2 = Math.floor(Math.random() * arr5.length);

				if(document.getElementById("number1").value==5){
					document.getElementById("demo2").innerHTML = arr5[num];
				}
				if(document.getElementById("number2").value==5){
					document.getElementById("demo3").innerHTML = arr5[num2];
				}
				

			break;

			case 6:
				
				var arr6 = ["1 1 1 1 1 1", "1 5" , "5 1", "1 1 1 1 2" , "1 1 1 2 1" ,
				 "1 1 2 1 1" , "1 2 1 1 1" , "2 1 1 1 1" , "2 2 2", "3 3" , "4 2", "2 4", "6"];
				
				num = Math.floor(Math.random() * arr6.length);
				num2 = Math.floor(Math.random() * arr5.length);
				if(document.getElementById("number1").value==6){
					document.getElementById("demo2").innerHTML = arr6[num];
				}
				if(document.getElementById("number2").value==6){
					document.getElementById("demo3").innerHTML = arr6[num2];
				}
				


			break;

			case 7:
				
				var arr7 = ["1 1 1 1 1 1 1", "2 5" , "5 2","2 1 1 1 1 1",
				 "1 2 1 1 1 1" , "1 1 2 1 1 1" , "1 1 1 2 1 1" , "1 1 1 1 2 1" , 
				 "1 1 1 1 1 2" , "2 2 1 1 1"," ", "2 2 3", "2 3 2", "3 2 2", "3 4" , "4 3", "7"];
				num = Math.floor(Math.random() * arr7.length);
				num2 = Math.floor(Math.random() * arr7.length);

				if(document.getElementById("number1").value==7){
					document.getElementById("demo2").innerHTML = arr7[num];
				}
				if(document.getElementById("number2").value==7){
					document.getElementById("demo3").innerHTML = arr7[num2];
				}
				


			break;

		}

			
			
		
	
}

